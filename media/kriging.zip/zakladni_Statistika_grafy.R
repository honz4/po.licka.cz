hist(data[,3])
boxplot(data[,3])

qqPlot(data[,3])
shapiro.test(data[,3])
shapiro.test(log(data[,3]))

sapply(data[,-1], shapiro.test)

#mimomimomimo
attach(data)
barplot(nezamestnanost_00, main = "Nezamnestnanost v roce 2000", col = "blue", names.arg = Stat)
x <- barplot(nezamestnanost_00, main = "Nezamnestnanost v roce 2000", col = "blue")
text(cex=0.75, x=x-0.25, y=0, as.character(Stat), xpd = T, srt = 90, adj = 2)

hist(nezamestnanost_12, main = "Nezamestnanost v roce 2012", col = "light blue")
