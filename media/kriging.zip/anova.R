#### ANOVA + Tukey HSD - analyza variance a v?cen?sobn? porovn?v?n? ####
#### zji??ov?n? rozd?l? mezi v?ce ne? dv?ma skupinami, srovn?n? vnitro- a mezi-skupinov?ho rozptylu ####
#### v p??pad? zam?tnut? H0: ?1 = ?2 nerovn? se ?3 nebo ?1 nerovn? se ?2 = ?3 nebo ?1 nerovn? se ?2 nerovn? se ?3 ####
# rozdeleni do skupin
data$skupina <- 1
data[10:18,'skupina'] <- 2
data[19:27,'skupina'] <- 3

# p?eveden? skupiny na faktor
data$skupina <- as.factor(data$skupina)

anova <- aov(nezamestnanost_00 ~  skupina, data = data)
summary(anova)

tukey <- TukeyHSD(anova)
plot(tukey)
