library(geoR)

#shapiro testem zjistime, jestli data potrebujeme logaritmovat

#potrebujeme, takze vytvorime 4 sloupec se zlogaritmovynama datama
data[,4] <- log(data[,3])

#Ud??l�me z dat Geodata, pomoc� coords.col stanov�me , �e sloupec  1 a 2 jsou sou??adnice X a Y a data.col=4 �sloupec 4 je Z sou??adnice
geodata <- as.geodata(data, coords.col=1:2, data.col=4)

plot(geodata, lowess = T) #s trendem, bez trendu by bylo jenom plot(geodata)

plot(geodata, lowess = T, trend = '1st') #s linearni regresi, 2nd s kvadratickou regresi
#Ve�ker� statistika geodat-  density (dole vpravo), Grafy (naho??e vpravo a dole vlevo) ukazuj�, �e data nejsou nijak soust??ed??n� na ��dnou sv??tovou stranu

#### vytvorime variogram
var<-variog(geodata)
plot(var)

#Nugget efect=0,2 prahov� hodnota je v distance=4000 
var <- variog(geodata, max.dist=4000)

vario.fit <- variofit(var, cov.model = "spherical", nugget = 0.2, max.dist = 4000, fix.nugget = TRUE)


summary(geodata$coords)
#Min a max X a Y, velikost pixelu 100x100
loci <- expand.grid(seq(3800,7100,b=100),seq(73800,78900,b=100))
par(mfrow = c(1,2))

kc <- krige.conv(geodata,loc=loci,krige=krige.control(obj.model=vario.fit))
# krige.conv: model with constant mean
# krige.conv: Kriging performed using global neighbourhood 
# Data mus�me odlogaritmovat a zobrazit je zpr�vn??
par(mfrow = c(1,2))
image(kc, value = exp(kc$predict), col = terrain.colors(12))
contour(kc,value = exp(kc$predict), nlev = 20, add=T)- vlo��me vrstevnice

#z 12!!!
kc <- krige.conv(geodata,loc=loci,krige=krige.control(obj.model=vario.fit))
# e=exp(1)
par(mfrow = c(1,2))
image(kc, value = exp(kc$predict), col = terrain.colors(12))
contour(kc,value = exp(kc$predict), nlev = 20, add=T)

image(kc, value = exp(sqrt(kc$krige.var)))
contour(kc,value = exp(sqrt(kc$krige.var)), add=T)
par(mfrow = c(1,1))

