# aritmeticky prumer
mean(data.2012[,2], na.rm = T)

# pripojeni datove sady, pouzivaji se jen nazvy sloupcu
attach(data.2012)

# median
median(nezamestnanost, na.rm = T)
sapply(data.2012[,2:5],median, na.rm = T)

#kvantily
quantile(data.2012[,2], na.rm = T)

#geometricky prumer
gmean <- function(x) exp(mean(log(x))) #definice funkce
gmean(na.omit(data.2012[,2]))

#harmonicky prumer
hmean <- function(x) 1/mean(1/x)
hmean(na.omit(data.2012[,2]))

# minimum a maximum
min(data.2012[,2], na.rm = T)
max(data.2012[,2], na.rm = T)

# rozsah
min <- min(data.2012[,2], na.rm = T)
max <- max(data.2012[,2], na.rm = T)
max - min

#variacni rozpeti
range(data.2012[,2], na.rm = T)

IQR(data.2012[,2], na.rm = T)

# prumerna absolutni odchylka od prumeru
aad(data.2012[,2], na.rm = T)

# median absolutni odchylky od medianu
mad(data.2012[,2], na.rm = T)

# rozptyl neboli variance
var(data.2012[,2], na.rm = T)

# smerodatna odchylka
sqrt(var(data.2012[,2], na.rm = T))

sd(data.2012[,2], na.rm = T)


#### miry tvaru ####
# sikmost
library(e1071)
skewness(data.2012[,2], na.rm=T)

#spicatost
kurtosis(data.2012[,2], na.rm=T)

#### automaticky vypis zakladni statistiky ####
summary(data.2012)
fivenum(data.2012[,2], na.rm=T)

# automaticky vypis vcetne charakteristik variability
library(psych)
describe(data.2012[,2], na.rm=T)
