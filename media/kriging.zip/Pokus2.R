library(psych)
describe(data1[,3])
var(data1[,3])

hist(data1[,3])
boxplot(data1[,3])
barplot(data1[,3])

library(car)
qqPlot(data1[,3])

shapiro.test(data1[,3])

library(geoR)
geodata  <- as.geodata(data1, coords.col=1:2, data1.col = 3)

data1[,4] <- log(data1[,3])


#line?rn? regrese
attach(data2)
cor(data2[,1], data2[,2])
lm <- lm(data2[,1] ~ data2[,2])
summary(lm)
#multiple R-squared = koeficient determinace
#0-1, c?m bl?? 1 t?m lep?? pr.: 0.7 = 70% = kvalita modelu!!, koeficient determinace

#kvadratick? regrese
lm <- lm(data2[,1] ~ data2[,2] + I(data[,2]^2))

#kubick? regrese
lm <- lm(data2[,1] ~ data2[,2] + I(data2[,2]^2) + I(data2[,2]^3))